/* ADC1 Example

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <stdio.h>
#include <stdlib.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "driver/adc.h"
#include "esp_adc_cal.h"

#define DEFAULT_VREF    1100        //Use adc2_vref_to_gpio() to obtain a better estimate
#define NO_OF_SAMPLES   64          //Multisampling

#define GPIO_OUTPUT_IO_1    	4	//26
#define GPIO_OUTPUT_PIN_SEL1  	(1ULL<<GPIO_OUTPUT_IO_1)
#define GPIO_OUTPUT_IO_2    	21	//33
#define GPIO_OUTPUT_PIN_SEL2	(1ULL<<GPIO_OUTPUT_IO_2)


#define BLINK_GPIO 4 /*CONFIG_BLINK_GPIO*/

static esp_adc_cal_characteristics_t *adc_chars;
static const adc_channel_t channel = ADC_CHANNEL_6;     //GPIO34 if ADC1, GPIO14 if ADC2
static const adc_atten_t atten = ADC_ATTEN_DB_0;
static const adc_unit_t unit = ADC_UNIT_1;

static void check_efuse()
{
    //Check TP is burned into eFuse
    if (esp_adc_cal_check_efuse(ESP_ADC_CAL_VAL_EFUSE_TP) == ESP_OK) {
        printf("eFuse Two Point: Supported\n");
    } else {
        printf("eFuse Two Point: NOT supported\n");
    }

    //Check Vref is burned into eFuse
    if (esp_adc_cal_check_efuse(ESP_ADC_CAL_VAL_EFUSE_VREF) == ESP_OK) {
        printf("eFuse Vref: Supported\n");
    } else {
        printf("eFuse Vref: NOT supported\n");
    }
}

static void print_char_val_type(esp_adc_cal_value_t val_type)
{
    if (val_type == ESP_ADC_CAL_VAL_EFUSE_TP) {
        printf("Characterized using Two Point Value\n");
    } else if (val_type == ESP_ADC_CAL_VAL_EFUSE_VREF) {
        printf("Characterized using eFuse Vref\n");
    } else {
        printf("Characterized using Default Vref\n");
    }
}

void app_main()
{
    gpio_config_t io_conf;

	//Configuring GPIO as OP
    io_conf.intr_type = GPIO_PIN_INTR_DISABLE;			//disable interrupt
    io_conf.mode = GPIO_MODE_OUTPUT;					//set as output mode
    io_conf.pin_bit_mask = GPIO_OUTPUT_PIN_SEL1;		//bit mask of the pins that you want to set,e.g.GPIO18/19
    io_conf.pull_down_en = 0;							//disable pull-down mode
    io_conf.pull_up_en = 0;								//disable pull-up mode
    gpio_config(&io_conf);								//configure GPIO with the given settings

	//Configuring GPIO as OP
    io_conf.intr_type = GPIO_PIN_INTR_DISABLE;			//disable interrupt
    io_conf.mode = GPIO_MODE_OUTPUT;					//set as output mode
    io_conf.pin_bit_mask = GPIO_OUTPUT_PIN_SEL2;		//bit mask of the pins that you want to set,e.g.GPIO18/19
    io_conf.pull_down_en = 0;							//disable pull-down mode
    io_conf.pull_up_en = 0;								//disable pull-up mode
    gpio_config(&io_conf);								//configure GPIO with the given settings

    //Check if Two Point or Vref are burned into eFuse
    check_efuse();

    //Configure ADC
    if (unit == ADC_UNIT_1) {
        adc1_config_width(ADC_WIDTH_BIT_12);
        adc1_config_channel_atten(channel, atten);
    } else {
        adc2_config_channel_atten((adc2_channel_t)channel, atten);
    }

    //Characterize ADC
    adc_chars = calloc(1, sizeof(esp_adc_cal_characteristics_t));
    esp_adc_cal_value_t val_type = esp_adc_cal_characterize(unit, atten, ADC_WIDTH_BIT_12, DEFAULT_VREF, adc_chars);
    print_char_val_type(val_type);


    gpio_pad_select_gpio(BLINK_GPIO);
    /* Set the GPIO as a push/pull output */
    gpio_set_direction(BLINK_GPIO, GPIO_MODE_OUTPUT);
    uint32_t threshold = 45;
	
    //Continuously sample ADC1
    while (1) {
        uint32_t adc_reading = 0;

        gpio_set_level(GPIO_OUTPUT_IO_1, 1);

        //Multisampling
        for (int i = 0; i < NO_OF_SAMPLES; i++) {
            if (unit == ADC_UNIT_1) {
                adc_reading += adc1_get_raw((adc1_channel_t)channel);
            } else {
                int raw;
                adc2_get_raw((adc2_channel_t)channel, ADC_WIDTH_BIT_12, &raw);
                adc_reading += raw;
            }
        }
        adc_reading /= NO_OF_SAMPLES;
        //Convert adc_reading to voltage in mV
        uint32_t voltage = esp_adc_cal_raw_to_voltage(adc_reading, adc_chars);
		//float tempC = (voltage - .5) / 100;
		//float tempF = (tempC * 1.8) + 32;

                  float tempC = (voltage * 0.1) / 100;
                  float tempF = ((tempC * 1.8) + 32) * 2;
		
		
        printf("Raw: %d\tVoltage: %dmV\n", adc_reading, voltage);
		printf("Celsius: %f\t fahrenheit:%f\n", tempC, tempF);
		
		if (threshold < tempC)
		{
			printf("Turning on the LED-Green\n");
			gpio_set_level(BLINK_GPIO, 1);
			vTaskDelay(1000 / portTICK_PERIOD_MS);
		}
		else if (threshold >= tempC)
		{
			
			printf("Turning on the LED-Red\n");
			gpio_set_level(BLINK_GPIO, 1);
			vTaskDelay(1000 / portTICK_PERIOD_MS);
		}
		else
		{
			printf("Turning off the LEDs \n");
		    gpio_set_level(BLINK_GPIO, 0);
		}
		
		
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}


